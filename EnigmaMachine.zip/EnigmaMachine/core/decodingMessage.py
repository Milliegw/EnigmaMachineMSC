# def decode_message(plugboard, selected_rotors, selected_reflector, encoded_message):
#     """
#     Decodes a message by passing it through the same Enigma machine settings
#     that were used for encoding.
#     """
#     return encode_message(plugboard, selected_rotors, selected_reflector, encoded_message)

